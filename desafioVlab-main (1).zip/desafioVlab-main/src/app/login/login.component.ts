import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../services/auth.service.service';
interface FormProps {
  username: FormControl<string | null>
  password: FormControl<string | null>
}
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  loginForm: FormGroup<FormProps> = this.formBuilder.group({
    username: ['', Validators.required],
    password: ['', Validators.required]
  })

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthService
  ) {
    if(authenticationService.currentUserOn) {
      this.router.navigate(['/'])
    }
   }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    })
  }


  onSubmit(){
    if(this.loginForm.invalid) return
    const response = this.authenticationService.login(this.loginForm.controls.username.value!, this.loginForm.controls.password.value!)
    if(!response){
      alert('Usuário ou senha inválidos!')
      return
    }
    alert('Logado com sucesso!')
    this.router.navigate(['/'])
  }
}
