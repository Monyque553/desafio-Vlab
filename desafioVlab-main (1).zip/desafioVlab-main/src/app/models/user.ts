export class User {
  username: string;
  email: string;
  foundation: string;
  position: string;
  password: string;
}