import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUser = new BehaviorSubject<User | null>(JSON.parse(localStorage.getItem('currentUser')!))

  constructor() { }

  public get currentUserOn(): User | null {
    return this.currentUser.value
  }

  login(username: string, password: string) {
    const users = JSON.parse(localStorage.getItem('users')!)
    const checkLogin = users?.findIndex((e: User) => e.username === username && e.password === password)
    if(checkLogin >= 0) {
      localStorage.setItem('currentUser', JSON.stringify(users[checkLogin]));
      this.currentUser.next(users[checkLogin])
      return true;
    }
    return false;
  }

  logout() {
    localStorage.removeItem('currentUser')
    this.currentUser.next(null)
  }

  register(user: User) {
    const users = JSON.parse(localStorage.getItem('users')!) || []
    const alreadyExist = users?.findIndex((e: User) => e.username === user.username)
    if((!users.length )|| alreadyExist < 0) {
      users.push(user)
      localStorage.setItem('users', JSON.stringify(users))
    }
  }
}
