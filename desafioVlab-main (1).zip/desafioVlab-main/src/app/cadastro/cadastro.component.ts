import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service.service';
@Component({
  selector: 'app-cadastro',
  templateUrl: './cadastro.component.html',
  styleUrls: ['./cadastro.component.css']
})
export class CadastroComponent implements OnInit {

  signUpForm: FormGroup = this.formBuilder.group({
    username: ['', Validators.required],
    email: ['', Validators.required],
    foundation: ['', Validators.required],
    position: ['', Validators.required],
    password: ['', Validators.required],
  })
  
  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private authenticationService: AuthService
  ) {
    if(authenticationService.currentUserOn) {
      this.router.navigate(['/'])
    }
   }

    ngOnInit(): void {
      this.signUpForm = this.formBuilder.group({
        username: ['', Validators.required],
        email: ['', Validators.required],
        foundation: ['', Validators.required],
        position: ['', Validators.required],
        password: ['', Validators.required],
      })
    }

    onSubmit() {
      if(this.signUpForm.invalid) return
      this.authenticationService.register(this.signUpForm.value)
      alert('Registrado com sucesso!')
      this.router.navigate(['/login'])
    }

}
